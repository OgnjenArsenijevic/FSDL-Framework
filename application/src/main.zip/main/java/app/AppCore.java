package app;

public class AppCore {

    public static void main(String[] args) {
        (new Controller()).register("nemanjaa", "cao");
    }

}
